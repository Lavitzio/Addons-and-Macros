if( GetLocale() ~= "zhCN" ) then return end
--local L = {
--}

--local LunaUF = select(2, ...)
--LunaUF.L = setmetatable(L, {__index = LunaUF.L})