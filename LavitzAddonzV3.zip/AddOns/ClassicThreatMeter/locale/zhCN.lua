local A, C, L, _ = unpack(select(2, ...))
if GetLocale() ~= "zhCN" then return end

-----------------------------
--	zhCN client
-----------------------------
-- main frame
L.gui.threat		= "威胁"