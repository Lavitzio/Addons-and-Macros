local A, C, L, _ = unpack(select(2, ...))
if GetLocale() ~= "zhTW" then return end

-----------------------------
--	zhTW client
-----------------------------
-- main frame
L.gui.threat		= "威脅"