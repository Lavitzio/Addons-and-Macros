# ClassicThreatMeter
A simple threat meter for WoW Classic (1.13.2)

**Notes:**
 - At present, it will require other players have this AddOn also enabled in order to track their threat similar to how KTM/Omen required compatible AddOns communicating threat to one another.
 - Mobs with threat reset events aren't currently worked in, so threat wipes won't appropriately reset the data in these cases.
 - I'm unable to presently test this due to lacking beta access.
