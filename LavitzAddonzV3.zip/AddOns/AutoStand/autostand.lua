local f = CreateFrame("Frame", "AutoStand", UIParent)
f:RegisterEvent("UI_ERROR_MESSAGE")

f:SetScript("OnEvent", function(self, event, arg1, arg2, ...)
	if event == "UI_ERROR_MESSAGE" then
		if arg1 == 50 and arg2 == "You must be standing to do that" then
			DoEmote("STAND")
		end

	end
end)

f:Hide()